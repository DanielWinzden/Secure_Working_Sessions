#!/bin/bash
#encoding=UTF-8
echo "[ Your current session dir ] :"
tree /home/gomora/1/
sleep 9000