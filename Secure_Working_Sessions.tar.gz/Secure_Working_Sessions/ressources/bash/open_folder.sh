#!/bin/bash
nemo '/home/deep_blue/Music/test02/' >/dev/null 2>&1 </dev/null &