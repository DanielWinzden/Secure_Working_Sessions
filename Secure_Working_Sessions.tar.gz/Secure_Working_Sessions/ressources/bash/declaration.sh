#!/bin/bash
mplayer /home/Secure_Working_Sessions/ressources/sounds/declaration.wav >/dev/null 2>&1 </dev/null &
