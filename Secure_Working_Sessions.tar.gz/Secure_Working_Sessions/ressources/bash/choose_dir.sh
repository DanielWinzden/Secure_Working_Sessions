#!/bin/bash
cd /home/
zenity --file-selection --title="Choose a directory" --directory > /home/Secure_Working_Sessions/ressources/files/dir
