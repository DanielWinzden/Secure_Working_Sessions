#!/bin/bash
python /home/Secure_Working_Sessions/ressources/python/new_session.py >/dev/null 2>&1 </dev/null &
