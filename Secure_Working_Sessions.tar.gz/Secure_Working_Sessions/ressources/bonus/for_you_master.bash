xterm -geometry 79x80+350+400 -hold -e python ./for_you_master-left.py | xterm -geometry 79x80+830+400 -hold -e python ./for_you_master-right.py
