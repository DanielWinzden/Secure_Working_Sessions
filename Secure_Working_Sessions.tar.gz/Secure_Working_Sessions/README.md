# Secure_Working_Sessions
This app helps you to work free and secured, to preserve integrity of you work, and intelligence property.
